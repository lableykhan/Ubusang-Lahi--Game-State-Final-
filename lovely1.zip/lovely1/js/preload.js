preloadGame = {
	preload:function() {

			game.load.image('bg','img/puno2.png');
			game.load.image('ground','img/plat.png');
			game.load.image('grounds','img/flat.png');
			game.load.image('groundss','img/ladd.png');
			game.load.image('groundse','img/ladd.png');
			game.load.image('fire','img/bato.png');
			game.load.image('title','img/harap.png',800,600);
			game.load.image('start', 'img/start.png');

			game.load.image('btn_paused', 'img/pause2.png');
			game.load.image('btn_pause', 'img/pause.png');




			game.load.spritesheet('dude','img/gwapo.png',32,48);
			game.load.spritesheet('enemy','img/violet.png',32,48);
			game.load.spritesheet('enemy1','img/red.png',32,48);
			game.load.spritesheet('enemy2','img/pink.png',32,48);
			game.load.spritesheet('enemy3','img/gwapo2.png',32,48);
			game.load.spritesheet('enemy4','img/red.png',32,48);
			game.load.spritesheet('enemy5','img/gwapo2.png',32,48);
			game.load.spritesheet('enemy6','img/violet.png',32,48);
			game.load.spritesheet('enemy7','img/pink.png',32,48);
			game.load.spritesheet('enemy8','img/gwapo2.png',32,48);
			game.load.spritesheet('enemy9','img/violet.png',32,48);
			game.load.spritesheet('enemy10','img/pink.png',32,48);
			game.load.spritesheet('enemy11','img/red.png',32,48);
			game.load.spritesheet("button","img/btn-ups.png",100,100);
			game.load.spritesheet("button1","img/btn-left.png",100,100);
			game.load.spritesheet("button2","img/btn-right.png",100,100);

			game.load.image('gameover1','img/tgameover.png');
			game.load.image('tiu','img/times.png');

			game.load.image('about','img/btn-about.png');
			game.load.image('back2','img/back.png');

			game.load.audio("bgmusic","audio/party.mp3");
			game.load.audio('boo', 'audio/gasp.mp3');
			game.load.audio('yay', 'audio/FIREBALL.wav');
	},
	create:function(){
			game.state.start('menuGame');
	},
}