var w = 800,h = 600;
var platforms,platformers,player,keyboard,score,score = 0,enemyMoveRight,killcoins,killPlayerr,enemyMoveRight,enemyMoveLeft,enemy1MoveRight,enemy2MoveRight,enemy3MoveRight,enemy4MoveRight,enemy5MoveRight,enemy6MoveRight,enemy7MoveRight,enemy1MoveLeft,enemy2MoveLeft,enemy3MoveLeft,enemy4MoveLeft,enemy5MoveLeft,enemy6MoveLeft,enemy7MoveLeft,enemy7MoveDown,enemy7MoveUp,time,lundagNaruto,kananNaruto,kaliwaNaruto,tigilTuloy, bestScore,getScore,Fires,coins,gameOverText,scoreText,fire, lifeText, life = 1,bestScoreText,enemy6MoveUp,enemy6MoveDown,enemy7MoveUp,enemy7MoveDown,enemy8MoveUp,enemy8MoveUp,shineDiamond,enemy1MoveDown,enemy1MoveUp,shineDiamonds,explodeFire,btn, timeText,time, bestScore,getScore,Fires,coins,gameOverText,scoreText,fire, lifeText, life = 3,lundagNaruto,kananNaruto,kaliwaNaruto,bestScoreText,shineDiamond,shineDiamonds,explodeFire,btn, timeText,tusok,plat;
//var boundsRight = 4000;
var duration=31;
var titlepage;
var startButton;
var loopAudio;
var camera;
var enemy8MoveDown, enemy9MoveRight,enemy10MoveRight,enemy10MoveLeft, enemy9MoveLeft, enemy11MoveRight, enemy11MoveLeft;
var menu;
var gameOver,gameOver1,gameOver2;
var gameOver1,gameOver2;
var restart;
  	this.time;      //  the clock (Phaser.Time)
    this.game;      //  a reference to the currently running game (Phaser.Game)
    var paused;
	this._timeCounter = null;
	this._leftTime = null;
	this._leftTimeText = null;
	var timesup_title = null;

var actionOnClick;
var killFire, killenemy,killenemy1,killenemy2,killenemy3,killenemy4,killenemy5,killenemy6,killenemy7,killenemy8,killenemy9,killenemy10,killenemy11;
var updateTime;
var looped;
var about;


var game = new Phaser.Game(800, 600, Phaser.CANVAS, '');

game.state.add('bootGame', bootGame);
game.state.add('preloadGame', preloadGame);
game.state.add('menuGame', menuGame);
game.state.add('playGame', playGame);
game.state.add('winGame', winGame);
game.state.add('aboutGame', this.aboutGame);

game.state.start('bootGame');