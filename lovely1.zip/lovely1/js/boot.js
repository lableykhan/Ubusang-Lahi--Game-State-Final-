bootGame = {
	create:function(){
		game.physics.startSystem(Phaser.Physics.ARCADE);
		
		
		keyboard = game.input.keyboard.createCursorKeys();
		
		game.scale.scaleMode = Phaser.ScaleManager.SHOW_ALL;
		game.scale.forceLandscape = true;
		game.scale.pageAlignHorizontally = true;


        bgmusic = game.add.audio('bgmusic');
        bgmusic.play('',0,1,true);
        
	       
		
		
		
		game.state.start('preloadGame');
		
		},
}