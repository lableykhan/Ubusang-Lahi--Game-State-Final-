playGame = {
	create: function () {
		
			game.add.sprite(0,0, 'bg');
			//game.world.setBounds(0,0,boundsRight,0);
			
			button = game.add.button(650,450,"button",this.lundagNaruto);
		   	button1 = game.add.button(100,450,"button1",this.kananNaruto);
		   	button2 = game.add.button(250,445,"button2",this.kaliwaNaruto);

		   	 pause_label = game.add.button(380,10, 'btn_pause');
				pause_label.inputEnabled = true;
				pause_label.events.onInputUp.add(function (){
					game.paused = true;
					menu = game.add.sprite(w/2,h/2,'btn_paused');
					menu.anchor.setTo(0.5,0.5);
					choiseLabel = game.add.text (w/2,h-240, 'Click unpause button to continue',{fill: 'white'});
					choiseLabel.anchor.setTo(0.5,0.5);
					 });
				game.input.onDown.add(unpause,self);
				function unpause(event){
				if(game.paused){
					menu.destroy();
					choiseLabel.destroy();
					
					game.paused = false;
				}
				}

			

			lad = game.add.group();
			lad.enableBody = true;

			var ledge = lad.create(268,140,'groundss'); // 1 pinaka baba
			ledge.body.immovable = true;
			var ledge = lad.create(268,-88,'groundss'); // 1 pinaka baba
			ledge.body.immovable = true;
			var ledge = lad.create(268,360,'groundss'); // 1 pinaka baba
			ledge.body.immovable = true;
			var ledge = lad.create(635,140,'groundse'); // 1 pinaka baba
			ledge.body.immovable = true;
			var ledge = lad.create(635,-88,'groundse'); // 1 pinaka baba
			ledge.body.immovable = true;
			var ledge = lad.create(635,360,'groundse'); // 1 pinaka baba
			ledge.body.immovable = true;
			var ledge = lad.create(450,295,'groundse'); // 1 pinaka baba
			ledge.body.immovable = true;


			platforms = game.add.group();
			platforms.enableBody = true;



			var ground = platforms.create(-90,game.world.height -40,'ground');
			ground.scale.setTo(3.7,1);
			ground.body.immovable = true;

			var ledge = platforms.create(0,415,'grounds'); // 1 pinaka baba
			ledge.body.immovable = true;
			
			ledge = platforms.create(290,270,'grounds'); // 2
			ledge.body.immovable = true;


			ledge = platforms.create(0,140,'grounds'); // 3
			ledge.body.immovable = true;


			ledge = platforms.create(520,415,'grounds'); // katapat ng 1
			ledge.body.immovable = true;
			
			
			
			ledge = platforms.create(540,130,'grounds'); // katapat ng 3
			ledge.body.immovable = true;
			
			
			Fire = game.add.group();
			Fire.enableBody = true;
			this.createFires(500);
			
			this.time.advancedTiming = true;
	        this._timeCounter = 0;
	        this._leftTime = 25;    
	        this._leftTimeText = this.add.text(570, 50, 'Time: 25', { fontSize: '28px', fill: 'red' });
	        

	        yaymusic = game.add.audio('yay');
	        boomusic = game.add.audio('boo');
	        bgmusic = game.add.audio('bgmusic');
	        // youwin = game.add.audio('youwin');
	        bgmusic.play('',0,1,true);
	        this.loopAudio(49000);

			player = game.add.sprite(32,game.world.height -150,'dude');
			
			
			game.physics.arcade.enable(player);
			game.physics.arcade.enable(platforms);
			
			player.body.bounce.y = 0.2;
			player.body.gravity.y = 800;
			player.body.collideWorldBounds = true;
			
			player.animations.add('left',[0,1,2,3],10,true);
			player.animations.add('right',[5,6,7,8],10,true);
			player.body.velocity.x =0;
			
			enemy = game.add.sprite(0,90,"enemy");
			enemy.animations.add('left', [0,1,2,3], 10, true);
			enemy.animations.add('right', [5,6,7,8], 10, true);
			enemy.scale.x=1;
			enemy.scale.y=1;
			game.physics.arcade.enable(enemy);
			enemy.body.collideWorldBounds = true;

			enemy1 = game.add.sprite(268,190,"enemy1");
			enemy1.animations.add('left', [0,1,2,3], 10, true);
			enemy1.animations.add('right', [5,6,7,8], 10, true);
			enemy1.scale.x=1;
			enemy1.scale.y=1;
			game.physics.arcade.enable(enemy1);
			enemy1.body.collideWorldBounds = true;

			enemy2 = game.add.sprite(0,90,"enemy2");
			enemy2.animations.add('left', [0,1,2,3], 10, true);
			enemy2.animations.add('right', [5,6,7,8], 10, true);
			enemy2.scale.x=1;
			enemy2.scale.y=1;
			game.physics.arcade.enable(enemy2);
			enemy2.body.collideWorldBounds = true;

			enemy3 = game.add.sprite(539,80,"enemy3");
			enemy3.animations.add('left', [0,1,2,3], 10, true);
			enemy3.animations.add('right', [5,6,7,8], 10, true);
			enemy3.scale.x=1;
			enemy3.scale.y=1;
			game.physics.arcade.enable(enemy3);
			enemy3.body.collideWorldBounds = true;

			enemy4 = game.add.sprite(800,80,"enemy4");
			enemy4.animations.add('left', [0,1,2,3], 10, true);
			enemy4.animations.add('right', [5,6,7,8], 10, true);
			enemy4.scale.x=1;
			enemy4.scale.y=1;
			game.physics.arcade.enable(enemy4);
			enemy4.body.collideWorldBounds = true;

			enemy5 = game.add.sprite(800,370,"enemy5");
			enemy5.animations.add('left', [0,1,2,3], 10, true);
			enemy5.animations.add('right', [5,6,7,8], 10, true);
			enemy5.scale.x=1;
			enemy5.scale.y=1;
			game.physics.arcade.enable(enemy5);
			enemy5.body.collideWorldBounds = true;

			enemy6 = game.add.sprite(635,370,"enemy6");
			enemy6.animations.add('left', [0,1,2,3], 10, true);
			enemy6.animations.add('right', [5,6,7,8], 10, true);
			enemy6.scale.x=1;
			enemy6.scale.y=1;
			game.physics.arcade.enable(enemy6);
			enemy6.body.collideWorldBounds = true;

			enemy7 = game.add.sprite(635,370,"enemy7");
			enemy7.animations.add('left', [0,1,2,3], 10, true);
			enemy7.animations.add('right', [5,6,7,8], 10, true);
			enemy7.scale.x=1;
			enemy7.scale.y=1;
			game.physics.arcade.enable(enemy7);
			enemy7.body.collideWorldBounds = true;

			enemy8 = game.add.sprite(268,190,"enemy8");
			enemy8.animations.add('left', [0,1,2,3], 10, true);
			enemy8.animations.add('right', [5,6,7,8], 10, true);
			enemy8.scale.x=1;
			enemy8.scale.y=1;
			game.physics.arcade.enable(enemy8);
			enemy8.body.collideWorldBounds = true;
			
			enemy9 = game.add.sprite(800,370,"enemy9");
			enemy9.animations.add('left', [0,1,2,3], 10, true);
			enemy9.animations.add('right', [5,6,7,8], 10, true);
			enemy9.scale.x=1;
			enemy9.scale.y=1;
			game.physics.arcade.enable(enemy9);
			enemy9.body.collideWorldBounds = true;

			enemy10 = game.add.sprite(0,370,"enemy10");
			enemy10.animations.add('left', [0,1,2,3], 10, true);
			enemy10.animations.add('right', [5,6,7,8], 10, true);
			enemy10.scale.x=1;
			enemy10.scale.y=1;
			game.physics.arcade.enable(enemy10);
			enemy10.body.collideWorldBounds = true;

			enemy11 = game.add.sprite(560,225,"enemy11");
			enemy11.animations.add('left', [0,1,2,3], 10, true);
			enemy11.animations.add('right', [5,6,7,8], 10, true);
			enemy11.scale.x=1;
			enemy11.scale.y=1;
			game.physics.arcade.enable(enemy11);
			enemy11.body.collideWorldBounds = true;

			keyboard = game.input.keyboard.createCursorKeys();

			game.timer=game.time.events.loop(Phaser.Timer.SECOND * 1,this.enemyMoveRight);
			game.timer=game.time.events.loop(Phaser.Timer.SECOND * 0.6,this.enemyMoveLeft);
			
			game.timer=game.time.events.loop(Phaser.Timer.SECOND * 2,this.enemy1MoveDown);
			game.timer=game.time.events.loop(Phaser.Timer.SECOND * 1,this.enemy1MoveUp);

			game.timer=game.time.events.loop(Phaser.Timer.SECOND * 1,this.enemy2MoveRight);
			game.timer=game.time.events.loop(Phaser.Timer.SECOND * 2,this.enemy2MoveLeft);
			
			game.timer=game.time.events.loop(Phaser.Timer.SECOND * 0.6,this.enemy3MoveRight);
			game.timer=game.time.events.loop(Phaser.Timer.SECOND * 2,this.enemy3MoveLeft);

			game.timer=game.time.events.loop(Phaser.Timer.SECOND * 2,this.enemy4MoveRight);
			game.timer=game.time.events.loop(Phaser.Timer.SECOND * 1,this.enemy4MoveLeft);

			game.timer=game.time.events.loop(Phaser.Timer.SECOND * 1,this.enemy5MoveRight);
			game.timer=game.time.events.loop(Phaser.Timer.SECOND * 2,this.enemy5MoveLeft);

			game.timer=game.time.events.loop(Phaser.Timer.SECOND * 1,this.enemy6MoveDown);
			game.timer=game.time.events.loop(Phaser.Timer.SECOND * 2,this.enemy6MoveUp);

			game.timer=game.time.events.loop(Phaser.Timer.SECOND * 1,this.enemy7MoveDown);
			game.timer=game.time.events.loop(Phaser.Timer.SECOND * 2,this.enemy7MoveUp);

			game.timer=game.time.events.loop(Phaser.Timer.SECOND * 1,this.enemy8MoveDown);
			game.timer=game.time.events.loop(Phaser.Timer.SECOND * 2,this.enemy8MoveUp);

			game.timer=game.time.events.loop(Phaser.Timer.SECOND * 1,this.enemy9MoveRight);
			game.timer=game.time.events.loop(Phaser.Timer.SECOND * 2,this.enemy9MoveLeft);
			
			game.timer=game.time.events.loop(Phaser.Timer.SECOND * 1,this.enemy10MoveRight);
			game.timer=game.time.events.loop(Phaser.Timer.SECOND * 2,this.enemy10MoveLeft);

			game.timer=game.time.events.loop(Phaser.Timer.SECOND * 0.5,this.enemy11MoveRight);
			game.timer=game.time.events.loop(Phaser.Timer.SECOND * 1,this.enemy11MoveLeft);
			
			bestScoreText = game.add.text(570,20,"bestScore: "+ playGame.getScore(),{fill:'blue'});
			scoreText = game.add.text(50,20,"SCORE: 0",{fill:'blue'});
			lifeText = game.add.text(50,50,"LIFE: 3",{fill:'red'});
			gameOverText = game.add.text(300,240,"",{fill:'red'});
			

			/*stateText = game.add.text(game.world.centerX,game.world.centerY,' ', { font: '30px Arial', fill: 'black' });
		    stateText.anchor.setTo(0.5, 0.5);
			game.scale.refresh();*/



			game.camera.follow(player,Phaser.Camera.FOLLOW_TOPDOWN);
			scoreText.fixedToCamera = true;
			bestScoreText.fixedToCamera = true;
			scoreText.fixedToCamera = true;
			bestScoreText.fixedToCamera = true;
			
			
		},

		 update:function() {
			game.physics.arcade.collide(player,platforms,0,0);
			//game.physics.arcade.collide(player,plat,0,0);
			//game.physics.arcade.collide(player,plat2,0,0);
			game.physics.arcade.overlap(player,Fire,this.killFire);
			game.physics.arcade.overlap(player,enemy,this.killenemy);
			game.physics.arcade.overlap(player,enemy1,this.killenemy1);
			game.physics.arcade.overlap(player,enemy2,this.killenemy2);
			game.physics.arcade.overlap(player,enemy3,this.killenemy3);
			game.physics.arcade.overlap(player,enemy4,this.killenemy4);
			game.physics.arcade.overlap(player,enemy5,this.killenemy5);
			game.physics.arcade.overlap(player,enemy6,this.killenemy6);
			game.physics.arcade.overlap(player,enemy7,this.killenemy7);
			game.physics.arcade.overlap(player,enemy8,this.killenemy8);
			game.physics.arcade.overlap(player,enemy9,this.killenemy9);
			game.physics.arcade.overlap(player,enemy10,this.killenemy10);
			game.physics.arcade.overlap(player,enemy11,this.killenemy11);





			var x= 0;
		    if(keyboard.left.isDown){
		         x++;
		        player.animations.play('left');
		        player.body.velocity.x = -200;
		        // bg.frame = 0;
		    }
		    else if(keyboard.right.isDown){
		         x++;
		        // bg.frame = 1;
		        player.animations.play('right');
		        player.body.velocity.x = 200;
		    }
		    else{
		        player.body.velocity.x = 0;
		        player.animations.stop();
		    }

		    if(keyboard.up.isDown && player.body.touching.down){
		        player.body.velocity.y = -500;
		    }
		     // update timer every frame
	        this._timeCounter += this.time.elapsed;
	        // if spawn timer reach one second (1000 miliseconds)
	        if(this._timeCounter > 1000) {
	            // reset it
	            this._timeCounter = 0;
	            this._leftTime --;
	            this._leftTimeText.text = 'Time: ' + this._leftTime;
	        }
	        
	        if(this._leftTime <= 0) {      
	            // this.quitGame();

	        gameover = game.add.button(0,0, 'tiu',this.gameOver1);
	        var pausedText = game.add.text(250, 360, "Tap anywhere to Menu.", { fontSize: '28px', fill: '#FFF' });
					        game.input.onDown.add(function(){
					            pausedText.destroy();
					            //this.game.paused = false;
					            game.state.start('menuGame');
					            //window.location.href=window.location.href;
					            
					        }, this);
					    }
				
	
			
		},


            render:function  () {
    
        		this.game.debug.text(this.game.time.fps + ' FPS', 350, 20, "#00ff00", "32px Courier");       
 
    		},
    		gameOver:function (){
			       window.location.href=window.location.href;

			},
    		gameOver1:function (){
			       window.location.href=window.location.href;

			},
			gameOver2:function (){
			       window.location.href=window.location.href;

			},

             createFires:function(time){
                setInterval(function(){
                    var size = Math.random();
                    this.Fires = Fire.create(100+ Math.random()*800,-100,"fire");
                    this.Fires.body.gravity.y = 100;
                    this.Fires.scale.x = size*4;
                    this.Fires.scale.y = size*4;
                    // diamonds.body.collideWorldBounds = true;
                    this.Fires.body.bounce.y = 0.7;
                },time)
            },

            loopAudio:function (time){
			    setInterval(function(){
			        bgmusic.play();
			    },time);
			},

			win:function (){
			        win.visible =! startButton.visible;
			    startButton.destroy();

			},

             enemyMoveRight:function() {
                
            			this.enemy.body.velocity.x = 320;
                        this.enemy.animations.play('right');

                 },
            enemyMoveLeft :function() {
                
            			this.enemy.body.velocity.x = -320;
                        this.enemy.animations.play('left');

                 },

             enemy1MoveDown:function() {
                
            		this.enemy1.body.velocity.y = -320;
            		this.enemy1.animations.play('down');

                 },
             enemy1MoveUp:function() {
                
            		this.enemy1.body.velocity.y =320;
            		this.enemy1.animations.play('up');

                 },

             enemy2MoveRight:function() {
                
            			this.enemy2.body.velocity.x = -320;
                        this.enemy.animations.play('right');

                 },
             enemy2MoveLeft:function() {
                
            			this.enemy2.body.velocity.x = 320;
                        this.enemy2.animations.play('left');

                 },
            enemy3MoveRight:function () {
                
            			this.enemy3.body.velocity.x = 320;
                        this.enemy3.animations.play('right');

                 },
            enemy3MoveLeft :function() {
                
            			this.enemy3.body.velocity.x = -320;
                        this.enemy3.animations.play('left');

                 },

            enemy4MoveRight:function () {
                
            			this.enemy4.body.velocity.x = -200;
                        this.enemy4.animations.play('right');

                 },
             enemy4MoveLeft:function() {
                
            			this.enemy4.body.velocity.x = 200;
                        this.enemy4.animations.play('left');

                 },
             enemy5MoveRight:function() {
                
            			this.enemy5.body.velocity.x = 250;
                        this.enemy5.animations.play('right');

                 },
            enemy5MoveLeft :function() {
                
            			this.enemy5.body.velocity.x = -250;
                        this.enemy5.animations.play('left');

                 },
             enemy6MoveDown:function() {
                
            		this.enemy6.body.velocity.y = -320;
            		this.enemy6.animations.play('down');

                 },
             enemy6MoveUp:function() {
                
            		this.enemy6.body.velocity.y =320;
            		this.enemy6.animations.play('up');

                 },
             enemy7MoveDown:function() {
                
            		this.enemy7.body.velocity.y = -500;
            		this.enemy7.animations.play('down');

                 },
            enemy7MoveUp :function() {
                
            		this.enemy7.body.velocity.y =500;
            		this.enemy7.animations.play('up');

                 },
            enemy8MoveDown :function() {
                
            		this.enemy8.body.velocity.y = -500;
            		this.enemy8.animations.play('down');

                 },
             enemy8MoveUp:function() {
                
            		this.enemy8.body.velocity.y =500;
            		this.enemy8.animations.play('up');

                 },
            enemy9MoveRight :function() {
                
            			this.enemy9.body.velocity.x = 200;
                        this.enemy9.animations.play('right');

                 },
            enemy9MoveLeft  :function () {
                
            			this.enemy9.body.velocity.x = -200;
                        this.enemy9.animations.play('left');

                 },

            enemy10MoveRight:function() {
                
            			this.enemy10.body.velocity.x = -300;
                        this.enemy10.animations.play('right');

                 },
            enemy10MoveLeft :function() {
                
            			this.enemy10.body.velocity.x = 300;
                        this.enemy10.animations.play('left');

                 },
            enemy11MoveRight:function () {
                
            			this.enemy11.body.velocity.x = -320;
                        this.enemy11.animations.play('right');

                 },
             enemy11MoveLeft:function() {
                
            			this.enemy11.body.velocity.x = 320;
                        this.enemy11.animations.play('left');

                },

            getScore:function(){
                return (localStorage.getItem("gameData") == null || localStorage.getItem("gameData") == "")?0:localStorage.getItem("gameData");
            },
            saveScore:function(score){
                localStorage.setItem("gameData",score);
            },

            lundagNaruto:function(){
                button.frame = 1;
                if(player.body.touching.down){

                    player.body.velocity.y = -500;
                }

                setTimeout(function(){
                    button.frame = 0;
                },300)
            },


            kananNaruto:function(){
               button1.frame = 1;
                //	if(keyboard.left.isDown){
               		player.body.velocity.x = -2500;
               		player.animations.add('left',[0,1,2,3,4],10,true);
               	//	}
                setTimeout(function(){
                	
                	player.animations.play('left');

                    button1.frame = 0;
                   },300)
            },


            kaliwaNaruto:function(){
                button2.frame = 1;
                //	if(keyboard.right.isDown){
                	player.animations.add('right',[5,6,7,8],10,true);
               		player.body.velocity.x = 2500;
               	//	}
                setTimeout(function(){
            		player.animations.play('right');

                    button2.frame = 0;
                   },100)
            },

              quitGame:function(pointer) {
		        // this._timesup_title = this.add.sprite((this.world.width - 400) / 2, (this.world.height - 100) / 2, 'timesup');
		        
		        this.game.paused = true;
		        var pausedText = this.add.text(160, 360, "Tap anywhere to Menu.", { fontSize: '28px', fill: '#FFF' });
		        this.input.onDown.add(function(){
		            pausedText.destroy();
		            this.game.paused = false;
		            this.state.start('MainMenu');
		        }, this);
    		},



            killFire:function(player,Fire){
              	 life--;
                lifeText.text = "LIFE: "+life;
                if(life>0){
                	 Fire.kill();
                	  yaymusic.play();
                }
                else{
                	gameover = game.add.button(0,0, 'gameover1',this.gameOver2);
                	player.kill();
                	var pausedText = game.add.text(250, 360, "Tap anywhere to Menu.", { fontSize: '28px', fill: '#FFF' });
					        game.input.onDown.add(function(){
					            pausedText.destroy();
					            //this.game.paused = false;
					            game.state.start('menuGame');
					            window.location.href=window.location.href;
					            
					        }, this);
					    }
                    
                    //game.input.onTap.addOnce(restart,this)  

                },
                // if(retrieve()<=score){
                //     saveScore(score);        
              //}
            
            restart:function (){
                window.location.href=window.location.href;
                stateText.visible = false;
            },
            killenemy:function(player,enemy){
                score = score + 1;
                scoreText.text = "SCORE:"+ score;
                enemy.kill();
                 boomusic.play();
                
            	
                if(playGame.getScore()<=score){
                    saveScore(score);
                    bestScoreText.text = "bestscore: "+score;
                }
            },
           
            killenemy1:function(player,enemy1){
                score = score + 1;
                scoreText.text = "SCORE:"+ score;
                enemy1.kill();
                boomusic.play();
                
            	
                if(playGame.getScore()<=score){
                    saveScore(score);
                    bestScoreText.text = "bestscore: "+score;
                }
            },
            killenemy2 :function(player,enemy2){
                score = score + 5;
                scoreText.text = "SCORE:"+ score;
                enemy2.kill();
                boomusic.play();
                
            	
                if(playGame.getScore()<=score){
                    saveScore(score);
                    bestScoreText.text = "bestscore: "+score;
                }
            },
            killenemy3:function (player,enemy3){
                score = score + 10;
                scoreText.text = "SCORE:"+ score;
                enemy3.kill();
                boomusic.play();
                
            	
                if(playGame.getScore()<=score){
                    saveScore(score);
                    bestScoreText.text = "bestscore: "+score;
                }
            },
            killenemy4:function(player,enemy4){
                score = score + 10;
                scoreText.text = "SCORE:"+ score;
                enemy4.kill();
                boomusic.play();
                
            	
                if(playGame.getScore()<=score){
                    saveScore(score);
                    bestScoreText.text = "bestscore: "+score;
                }
            },
             killenemy5 :function(player,enemy5){
                score = score + 5;
                scoreText.text = "SCORE:"+ score;
                enemy5.kill();
                 boomusic.play();
                
            	
                if(playGame.getScore()<=score){
                    saveScore(score);
                    bestScoreText.text = "bestscore: "+score;
                }
            },
            killenemy6  :function(player,enemy6){
                score = score + 2;
                scoreText.text = "SCORE:"+ score;
                enemy6.kill();
                 boomusic.play();
                
            	
                if(playGame.getScore()<=score){
                    saveScore(score);
                    bestScoreText.text = "bestscore: "+score;
                }
            },
            killenemy7:function(player,enemy7){
                score = score + 15;
                scoreText.text = "SCORE:"+ score;
                enemy7.kill();
                 boomusic.play();
            	
                if(playGame.getScore()<=score){
                    saveScore(score);
                    bestScoreText.text = "bestscore: "+score;
                }
            },
            killenemy8 :function(player,enemy8){
                score = score + 10;
                scoreText.text = "SCORE:"+ score;
                enemy8.kill();
                 boomusic.play();
            	
                if(playGame.getScore()<=score){
                    saveScore(score);
                    bestScoreText.text = "bestscore: "+score;
                }
            },
            killenemy9:function (player,enemy9){
                score = score + 1;
                scoreText.text = "SCORE:"+ score;
                enemy9.kill();
                 boomusic.play();
            	
                if(playGame.getScore()<=score){
                    saveScore(score);
                    bestScoreText.text = "bestscore: "+score;
                }
            },

            killenemy10:function(player,enemy10){
                score = score + 5;
                scoreText.text = "SCORE:"+ score;
                enemy10.kill();
                 boomusic.play();
            	
                if(playGame.getScore()<=score){
                    saveScore(score);
                    bestScoreText.text = "bestscore: "+score;
                }
            },
             killenemy11:function(player,enemy11){
                score = score + 3;
                scoreText.text = "SCORE:"+ score;
                enemy11.kill();
                 boomusic.play();
            	
                if(playGame.getScore()<=score){
                    saveScore(score);
                    bestScoreText.text = "bestscore: "+score;
                }
            }
 }

