aboutGame = {
	 create:function(){
	 		game.stage.backgroundColor="#00ffff";
	 	    devs = game.add.text(260, 80, 'Ubusan Lahi', {font: '50px serif', fill: '#cc3399'});
	 	    text =game.add.text(190,180, "It is based on traditional ", {font: '45px serif', fill: 'WHITE'});
			text =game.add.text(215,230, " game of Philippines", {font: '45px serif', fill: 'WHITE'});
            namesText = game.add.text(195, 470, 'ALVIN DIAZ', {font: '40px serif', fill: 'black'})
            dev = game.add.text(290, 320, 'Developed By:', {font: '40px serif', fill: 'white'}); 
            nameText = game.add.text(150, 400, 'LOVELY B. CHAN', {font: '40px serif', fill: 'black'}); 

            back = game.add.button(30,30,"back2",this.back);
	 },
	 update:function(){
	 	 
	 },
     back:function(){
      game.state.start("menuGame");
     },
}
 