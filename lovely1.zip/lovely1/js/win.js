winGame = {
	create:function(){
		game.stage.backgroundColor="#1000200";
		bestScoreText = game.add.text(570,20,"BestScore: "+ playGame.getScore(),{fill:'red'});
		scoreText = game.add.text(50,20,"SCORE: 0",{fill:'red'});
		gameOverText = game.add.text(300,240,"",{fill:'red'});
		timeText = game.add.text(570,50,"TIME: 60",{fill:'red'});

		stateText = game.add.text(game.world.centerX,game.world.centerY,' ', { font: '30px Arial', fill: 'black' });
		stateText.anchor.setTo(0.5, 0.5);
		game.scale.refresh();
		
		
		
	},
	update:function(){
	}
}