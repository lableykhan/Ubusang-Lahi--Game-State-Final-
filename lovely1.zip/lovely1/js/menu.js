menuGame = {
	create:function(){
		title = game.add.sprite(0,0,"title");
		
		start = game.add.button(game.width/2.4, game.height/1.6, "start",this.start);
		about = game.add.button(338,530,"about",about);
		


		
	},
	update:function(){
	},
	start:function(){
		game.state.start("playGame");
	},
	about:function(){
		game.state.start("aboutGame");
	},
	/*help:function(){
		game.state.start("helpGame");
	},*/
}
	